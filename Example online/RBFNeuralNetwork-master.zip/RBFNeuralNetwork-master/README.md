# RBFNeuralNetwork
RBF(Radial Basis Function) Neural Network Implementation in Python
Use gradient decent training algorithm with Guassian kernel
Use numpy for array function.
