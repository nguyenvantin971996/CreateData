class Pattern:
    def __init__(self, pattern_id, input, output):
        self.pattern_id= pattern_id
        self.input = input
        self.output = output
        
