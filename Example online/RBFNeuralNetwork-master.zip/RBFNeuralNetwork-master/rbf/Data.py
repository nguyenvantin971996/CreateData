class Data:
    def __init__(self, patterns, class_labels):
        self.patterns = patterns
        self.classLabels = class_labels
