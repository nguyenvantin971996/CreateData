# Genetic_Algorithm

The main driver code is `genetic_algorithm_code.py`, and you'll need `diabetes.txt` as input data set as well.
Feel free to try on other algorithms (optimizers) to see improvement in accuracy.

You may also refer to the [blog post](https://medium.com/swlh/genetic-algorithm-in-artificial-neural-network-5f5b9c9467d0)
